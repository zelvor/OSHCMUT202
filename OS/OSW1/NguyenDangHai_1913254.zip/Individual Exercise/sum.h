 #ifndef SUM_H_  
 #define SUM_H_  
 #include <stdio.h>  
 int sum(int a, int b);  
 #endif /* SUM_H_ */  
