 #ifndef SUB_H_  
 #define SUB_H_  
 #include <stdio.h>  
 int sub(int a, int b);  
 #endif /* SUB_H_ */  
